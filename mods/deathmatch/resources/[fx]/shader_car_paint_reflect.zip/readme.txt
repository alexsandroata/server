Resource: Shader Car Paint reflect v0.3.5
Author: Ren712
Contact: knoblauch700@o2.pl / Ren_712 on forum.mtasa.com

The reflection is based on screen source, giving an illusion 
of realtime reflection. Effect is similar to what is seen in ENB.  